# install packages
# pip install "chatterbot==1.0.0"
# pip install pytz
# pip install flask

Terminal based Chatbot :
![](TerminalChatbot.png)

UI Based Chatbot :
![](UIChatBot.png)
